// import React from "react";
// import Faculty from "./Faculty";

// function App() {
//   // data to be passed
//   const facultyData = {
//     name: "Ramesh",
//     subject: "Java",
//     experience: 13
//   };

//   return (
//     <div>
//       <h1>Faculty Information</h1>
//       {/* Passing data as props */}
//       <Faculty
//         facName={facultyData.name}
//         subject={facultyData.subject}
//         experience={facultyData.experience}
//       />
//     </div>
//   );
// }

//  export default App;
//  import Variableexample from './Variableexample.jsx'
//  function App(){
//    //ui design
//   return(
//    <div>
//      {/*---example of normal variable---*/}
//       <Variableexample/>
//       <h2>State Variable Example</h2>
//       <StateVariable/>
//        <h2>TextFieldExample</h2>
//        <SingleTextFieldExample/>
//      </div>
//    );
//    }
//  export default App;


// import TextFieldExample from "./TextFieldExample";

// function App() {
//   return (
//     <div>
//       <TextFieldExample />
//     </div>
//   );
// }

// export default App;

//  import React from "react";
//  import StudentForm from "./StudentForm";

//  function App() {
//   return (
//     <div>
//      <h1>Welcome to My React App</h1>
//      <StudentForm />
//     </div>
 
//   );
//  }
//  export default App;
// 
import { useState } from "react";
import FormComponent from "./FormComponent";
import DisplayComponent from "./DisplayComponent";

function App() {
  const [formData, setFormData] = useState({});

  return (
    <div>
      <FormComponent onSubmit={(data) => setFormData(data)} />
      <DisplayComponent data={formData} />
    </div>
  );
}

export default App;